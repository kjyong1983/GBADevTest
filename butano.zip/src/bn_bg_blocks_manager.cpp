/*
 * Copyright (c) 2020 Gustavo Valiente gustavo.valiente@protonmail.com
 * zlib License, see LICENSE file.
 */

#include "bn_bg_blocks_manager.h"

#include "bn_vector.h"
#include "bn_bgs_manager.h"
#include "bn_unordered_map.h"
#include "bn_config_bg_blocks.h"
#include "../hw/include/bn_hw_bg_blocks.h"

#include "bn_bg_maps.cpp.h"
#include "bn_bg_tiles.cpp.h"
#include "bn_bg_tiles_ptr.cpp.h"
#include "bn_bg_tiles_item.cpp.h"
#include "bn_regular_bg_map_ptr.cpp.h"
#include "bn_regular_bg_map_item.cpp.h"

#if BN_CFG_BG_BLOCKS_LOG_ENABLED
    #include "bn_log.h"

    static_assert(BN_CFG_LOG_ENABLED, "Log is not enabled");
#elif BN_CFG_LOG_ENABLED
    #include "bn_log.h"
#endif

namespace bn::bg_blocks_manager
{

namespace
{
    static_assert(BN_CFG_BG_BLOCKS_MAX_ITEMS > 0 && BN_CFG_BG_BLOCKS_MAX_ITEMS <= hw::bg_tiles::blocks_count());
    static_assert(power_of_two(BN_CFG_BG_BLOCKS_MAX_ITEMS));

    [[nodiscard]] constexpr int _tiles_to_half_words(int tiles)
    {
        return tiles * int(sizeof(tile) / 2);
    }

    [[nodiscard]] constexpr int _half_words_to_tiles(int half_words)
    {
        return half_words / int(sizeof(tile) / 2);
    }

    [[nodiscard]] constexpr int _blocks_to_half_words(int blocks)
    {
        return blocks * hw::bg_blocks::half_words_per_block();
    }

    [[nodiscard]] constexpr int _blocks_to_tiles(int blocks)
    {
        int half_words = _blocks_to_half_words(blocks);
        return _half_words_to_tiles(half_words);
    }

    [[nodiscard]] constexpr int _ceil_half_words_to_blocks(int half_words)
    {
        int result = half_words / hw::bg_blocks::half_words_per_block();

        if(half_words % hw::bg_blocks::half_words_per_block())
        {
            ++result;
        }

        return result;
    }

    [[nodiscard]] constexpr bool _big_map(int width, int height)
    {
        return width > 64 || height > 64;
    }


    constexpr const int max_items = BN_CFG_BG_BLOCKS_MAX_ITEMS;
    constexpr const int max_list_items = max_items + 1;


    enum class status_type
    {
        FREE,
        USED,
        TO_REMOVE
    };


    class item_type
    {

    public:
        const uint16_t* data = nullptr;
        unsigned usages = 0;
        optional<bg_tiles_ptr> tiles;
        optional<bg_palette_ptr> palette;
        uint16_t width = 0;
        uint16_t height = 0;
        uint8_t start_block = 0;
        uint8_t blocks_count = 0;
        uint8_t next_index = max_list_items;

    private:
        unsigned _status: 2 = unsigned(status_type::FREE);

    public:
        bool is_tiles: 1 = false;
        bool commit: 1 = false;

        [[nodiscard]] status_type status() const
        {
            return static_cast<status_type>(_status);
        }

        void set_status(status_type status)
        {
            _status = unsigned(status);
        }

        [[nodiscard]] int half_words() const
        {
            return width * height;
        }

        [[nodiscard]] int tiles_count() const
        {
            return _half_words_to_tiles(half_words());
        }

        [[nodiscard]] int tiles_offset() const
        {
            int tiles_start_block = tiles->id();
            int offset_blocks_count = tiles_start_block % hw::bg_blocks::tiles_alignment_blocks_count();
            int result = _blocks_to_tiles(offset_blocks_count);

            if(palette->bpp() == bpp_mode::BPP_8)
            {
                result /= 2;
            }

            return result;
        }

        [[nodiscard]] int palette_offset() const
        {
            return palette->id();
        }
    };


    class items_list
    {

    public:
        class iterator
        {

        public:
            friend class items_list;

            [[nodiscard]] int id() const
            {
                return _index;
            }

            iterator& operator++()
            {
                const item_type& item = _list->_items[_index];
                _index = item.next_index;
                return *this;
            }

            [[nodiscard]] item_type& operator*()
            {
                return _list->_items[_index];
            }

            item_type* operator->()
            {
                return _list->_items + _index;
            }

            [[nodiscard]] friend bool operator==(const iterator& a, const iterator& b)
            {
                return a._index == b._index;
            }

            [[nodiscard]] friend bool operator!=(const iterator& a, const iterator& b)
            {
                return ! (a == b);
            }

        private:
            int _index;
            items_list* _list;

            iterator(int index, items_list& list) :
                _index(index),
                _list(&list)
            {
            }
        };

        void init()
        {
            _free_indices.resize(max_items);

            for(int index = 0; index < max_items; ++index)
            {
                _free_indices[index] = int8_t(index + 1);
            }
        }

        [[nodiscard]] int size() const
        {
            return _free_indices.available();
        }

        [[nodiscard]] bool full() const
        {
            return _free_indices.empty();
        }

        [[nodiscard]] item_type& item(int index)
        {
            return _items[index];
        }

        [[nodiscard]] iterator before_begin()
        {
            return iterator(0, *this);
        }

        [[nodiscard]] iterator begin()
        {
            return iterator(_items[0].next_index, *this);
        }

        [[nodiscard]] iterator end()
        {
            return iterator(max_list_items, *this);
        }

        void push_front(const item_type& value)
        {
            insert_after(0, value);
        }

        iterator insert_after(int index, const item_type& value)
        {
            int free_index = _free_indices.back();
            _free_indices.pop_back();
            _items[free_index] = value;
            _insert_node_after(index, free_index);
            return iterator(free_index, *this);
        }

        iterator erase_after(int index)
        {
            _remove_node_after(index);
            return iterator(_items[index].next_index, *this);
        }

    private:
        item_type _items[max_list_items];
        vector<int8_t, max_items> _free_indices;

        void _join(int index, int new_index)
        {
            _items[index].next_index = uint8_t(new_index);
        }

        void _insert_node_after(int index, int new_index)
        {
            auto next_index = int(_items[index].next_index);
            _join(new_index, next_index);
            _join(index, new_index);
        }

        void _remove_node_after(int index)
        {
            auto next_index = int(_items[index].next_index);
            _free_indices.push_back(int8_t(next_index));

            auto next_next_index = int(_items[next_index].next_index);
            _join(index, next_next_index);
        }
    };


    struct create_data
    {
        const uint16_t* data_ptr;
        int blocks_count;
        int width;
        int height;
        bpp_mode bpp;
        optional<bg_tiles_ptr> tiles;
        optional<bg_palette_ptr> palette;

        static create_data from_tiles(const uint16_t* data_ptr, int half_words, bpp_mode bpp)
        {
            int blocks_count = _ceil_half_words_to_blocks(half_words);
            return create_data{ data_ptr, blocks_count, half_words, 1, bpp, nullopt, nullopt };
        }

        static create_data from_map(const uint16_t* data_ptr, const size& dimensions, bg_tiles_ptr&& tiles,
                                    bg_palette_ptr&& palette)
        {
            int width = dimensions.width();
            int height = dimensions.height();
            int blocks_count;

            if(_big_map(width, height))
            {
                blocks_count = _ceil_half_words_to_blocks(32 * 32);
            }
            else
            {
                blocks_count = _ceil_half_words_to_blocks(width * height);
            }

            return create_data{ data_ptr, blocks_count, width, height, palette.bpp(), move(tiles), move(palette) };
        }
    };


    class static_data
    {

    public:
        items_list items;
        unordered_map<const uint16_t*, int, max_items * 2> items_map;
        int free_blocks_count = 0;
        int to_remove_blocks_count = 0;
        bool check_commit = false;
        bool delay_commit = false;
    };

    BN_DATA_EWRAM static_data data;


    #if BN_CFG_BG_BLOCKS_LOG_ENABLED
        void _log_status()
        {
            BN_LOG("items: ", data.items.size());
            BN_LOG('[');

            for(const item_type& item : data.items)
            {
                if(item.status() == status_type::FREE)
                {
                    BN_LOG("    ",
                            "free",
                            " - start_block: ", item.start_block,
                            " - blocks_count: ", item.blocks_count);
                }
                else if(item.is_tiles)
                {
                    BN_LOG("    ",
                            (item.status() == status_type::USED ? "used" : "to_remove"),
                            "_tiles",
                            " - start_block: ", item.start_block,
                            " - blocks_count: ", item.blocks_count,
                            " - data: ", item.data,
                            " - usages: ", item.usages,
                            " - tiles: ", item.tiles_count(),
                            (item.commit ? " - commit" : " - no_commit"));
                }
                else
                {
                    BN_LOG("    ",
                            (item.status() == status_type::USED ? "used" : "to_remove"),
                            "_map",
                            " - start_block: ", item.start_block,
                            " - blocks_count: ", item.blocks_count,
                            " - data: ", item.data,
                            " - usages: ", item.usages,
                            " - width: ", item.width,
                            " - height: ", item.height,
                            " - tiles: ", (item.tiles ? item.tiles->id() : -1),
                            " - palette: ", (item.palette ? item.palette->id() : -1),
                            " - tiles_offset: ", (item.tiles ? item.tiles_offset() : -1),
                            " - palette_offset: ", (item.palette ? item.palette_offset() : -1),
                            (item.commit ? " - commit" : " - no_commit"));
                }
            }

            BN_LOG(']');

            BN_LOG("items_map: ", data.items_map.size());
            BN_LOG('[');

            for(const auto& items_map_item : data.items_map)
            {
                BN_LOG("    data: ", items_map_item.first,
                        " - start_block: ", data.items.item(items_map_item.second).start_block);
            }

            BN_LOG(']');

            BN_LOG("free_blocks_count: ", data.free_blocks_count);
            BN_LOG("to_remove_blocks_count: ", data.to_remove_blocks_count);
            BN_LOG("check_commit: ", (data.check_commit ? "true" : "false"));
            BN_LOG("delay_commit: ", (data.delay_commit ? "true" : "false"));
        }

        #define BN_BG_BLOCKS_LOG BN_LOG

        #define BN_BG_BLOCKS_LOG_STATUS \
            _log_status
    #else
        #define BN_BG_BLOCKS_LOG(...) \
            do \
            { \
            } while(false)

        #define BN_BG_BLOCKS_LOG_STATUS(...) \
            do \
            { \
            } while(false)
    #endif

    [[nodiscard]] int _find_tiles_impl(const uint16_t* tiles_data, [[maybe_unused]] int half_words)
    {
        auto items_map_iterator = data.items_map.find(tiles_data);

        if(items_map_iterator != data.items_map.end())
        {
            int id = items_map_iterator->second;
            item_type& item = data.items.item(id);
            BN_ASSERT(tiles_data == item.data, "Tiles data does not match item tiles data: ",
                      tiles_data, " - ", item.data);
            BN_ASSERT(half_words == item.half_words(), "Tiles count does not match item tiles count: ",
                      half_words, " - ", item.half_words());

            switch(item.status())
            {

            case status_type::FREE:
                BN_ERROR("Invalid item state");
                break;

            case status_type::USED:
                ++item.usages;
                break;

            case status_type::TO_REMOVE:
                item.usages = 1;
                item.set_status(status_type::USED);
                data.to_remove_blocks_count -= item.blocks_count;
                break;

            default:
                BN_ERROR("Invalid item status: ", int(item.status()));
                break;
            }

            BN_BG_BLOCKS_LOG("FOUND. start_block: ", data.items.item(id).start_block);
            BN_BG_BLOCKS_LOG_STATUS();

            return id;
        }

        BN_BG_BLOCKS_LOG("NOT FOUND");
        return -1;
    }

    [[nodiscard]] int _find_regular_map_impl(const regular_bg_map_item& map_item, const bg_tiles_ptr& tiles,
                                             const bg_palette_ptr& palette)
    {
        const regular_bg_map_cell* data_ptr = &map_item.cells_ref();
        auto items_map_iterator = data.items_map.find(data_ptr);

        if(items_map_iterator != data.items_map.end())
        {
            int id = items_map_iterator->second;
            item_type& item = data.items.item(id);
            BN_ASSERT(map_item.dimensions().width() == item.width, "Width does not match item width: ",
                      map_item.dimensions().width(), " - ", item.width);
            BN_ASSERT(map_item.dimensions().height() == item.height, "Height does not match item height: ",
                      map_item.dimensions().height(), " - ", item.height);
            BN_ASSERT(! item.tiles || tiles == *item.tiles,
                      "Tiles does not match item tiles: ", tiles.id(), " - ", item.tiles->id());
            BN_ASSERT(! item.palette || palette == *item.palette,
                      "Palette does not match item palette: ", palette.id(), " - ", item.palette->id());

            switch(item.status())
            {

            case status_type::FREE:
                BN_ERROR("Invalid item state");
                break;

            case status_type::USED:
                ++item.usages;
                break;

            case status_type::TO_REMOVE:
                item.usages = 1;
                item.set_status(status_type::USED);
                data.to_remove_blocks_count -= item.blocks_count;

                item.tiles = tiles;
                item.palette = palette;
                break;

            default:
                BN_ERROR("Invalid item status: ", int(item.status()));
                break;
            }

            BN_BG_BLOCKS_LOG("FOUND. start_block: ", data.items.item(id).start_block);
            BN_BG_BLOCKS_LOG_STATUS();

            return id;
        }

        BN_BG_BLOCKS_LOG("NOT FOUND");
        return -1;
    }

    void _commit_item(const item_type& item)
    {
        const uint16_t* source_data_ptr = item.data;

        if(! source_data_ptr)
        {
            return;
        }

        if(item.is_tiles)
        {
            uint16_t* destination_vram_ptr = hw::bg_blocks::vram(item.start_block);
            memory::copy(*source_data_ptr, item.half_words(), *destination_vram_ptr);
            return;
        }

        // Big maps are committed from bgs_manager:
        if(_big_map(item.width, item.height))
        {
            return;
        }

        uint16_t* destination_vram_ptr = hw::bg_blocks::vram(item.start_block);
        int tiles_offset = item.tiles_offset();
        int palette_offset = item.palette_offset();
        int half_words = item.half_words();

        if(tiles_offset)
        {
            if(palette_offset)
            {
                for(int index = 0; index < half_words; ++index)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_offset(
                                source_data_ptr[index], tiles_offset, palette_offset,
                                destination_vram_ptr[index]);
                }
            }
            else
            {
                for(int index = 0; index < half_words; ++index)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_tiles_offset(
                                source_data_ptr[index], tiles_offset,
                                destination_vram_ptr[index]);
                }
            }
        }
        else
        {
            if(palette_offset)
            {
                for(int index = 0; index < half_words; ++index)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_palette_offset(
                                source_data_ptr[index], palette_offset,
                                destination_vram_ptr[index]);
                }
            }
            else
            {
                memory::copy(*source_data_ptr, half_words, *destination_vram_ptr);
            }
        }
    }

    void _check_commit_item(int id, const uint16_t* data_ptr, bool delay_commit)
    {
        item_type& item = data.items.item(id);
        item.data = data_ptr;
        data.items_map.insert(data_ptr, id);

        if(delay_commit)
        {
            item.commit = true;
            data.check_commit = true;
        }
        else
        {
            _commit_item(item);
        }
    }

    [[nodiscard]] int _create_item(int id, int padding_blocks_count, bool delay_commit, create_data&& create_data)
    {
        item_type* item = &data.items.item(id);
        int blocks_count = create_data.blocks_count;

        if(padding_blocks_count)
        {
            BN_ASSERT(! data.items.full(), "No more items allowed");

            int new_item_blocks_count = item->blocks_count - padding_blocks_count;
            item->blocks_count = uint8_t(padding_blocks_count);

            item_type new_item;
            new_item.start_block = item->start_block + item->blocks_count;
            new_item.blocks_count = uint8_t(new_item_blocks_count);

            auto new_item_iterator = data.items.insert_after(id, new_item);
            id = new_item_iterator.id();
            item = &data.items.item(id);
        }

        bool is_tiles = ! create_data.palette;

        if(int new_item_blocks_count = item->blocks_count - blocks_count)
        {
            BN_ASSERT(! data.items.full(), "No more items allowed");

            int start_block = item->start_block;
            int alignment_blocks_count = hw::bg_blocks::tiles_alignment_blocks_count();
            bool create_item_at_back = ! is_tiles &&
                    (start_block % alignment_blocks_count == 0 ||
                     start_block / alignment_blocks_count != (start_block + blocks_count - 1) / alignment_blocks_count);

            if(create_item_at_back)
            {
                item->blocks_count -= blocks_count;

                item_type new_item;
                new_item.start_block = uint8_t(start_block + item->blocks_count);

                auto new_item_iterator = data.items.insert_after(id, new_item);
                id = new_item_iterator.id();
                item = &data.items.item(id);
            }
            else
            {
                item_type new_item;
                new_item.start_block = uint8_t(start_block + blocks_count);
                new_item.blocks_count = uint8_t(new_item_blocks_count);
                data.items.insert_after(id, new_item);
            }
        }

        switch(item->status())
        {

        case status_type::FREE:
            data.free_blocks_count -= blocks_count;
            break;

        case status_type::USED:
            BN_ERROR("Invalid item state");
            break;

        case status_type::TO_REMOVE:
            data.items_map.erase(item->data);
            data.to_remove_blocks_count -= blocks_count;
            break;

        default:
            BN_ERROR("Invalid item status: ", int(item->status()));
            break;
        }

        const uint16_t* data_ptr = create_data.data_ptr;
        item->data = data_ptr;
        item->blocks_count = uint8_t(blocks_count);
        item->tiles = move(create_data.tiles);
        item->palette = move(create_data.palette);
        item->width = uint16_t(create_data.width);
        item->height = uint8_t(create_data.height);
        item->usages = 1;
        item->set_status(status_type::USED);
        item->is_tiles = is_tiles;
        item->commit = false;

        if(data_ptr)
        {
            _check_commit_item(id, data_ptr, delay_commit);
        }

        return id;
    }

    template<bool tiles>
    [[nodiscard]] int _padding_blocks_count(int start_block, int blocks_count, bpp_mode bpp)
    {
        int result = 0;

        if(tiles)
        {
            int alignment_blocks_count = hw::bg_blocks::tiles_alignment_blocks_count();
            int extra_blocks_count = start_block % alignment_blocks_count;
            int max_blocks_count = bpp == bpp_mode::BPP_4 ?
                        hw::bg_blocks::max_bpp_4_tiles_blocks_count() :
                        hw::bg_blocks::max_bpp_8_tiles_blocks_count();

            if(blocks_count + extra_blocks_count > max_blocks_count)
            {
                result = alignment_blocks_count - extra_blocks_count;
            }
        }

        return result;
    }

    template<bool tiles>
    [[nodiscard]] int _create_impl(create_data&& create_data)
    {
        auto begin = data.items.begin();
        auto end = data.items.end();
        int blocks_count = create_data.blocks_count;
        bool check_to_remove_blocks = blocks_count <= data.to_remove_blocks_count;

        if(check_to_remove_blocks)
        {
            for(auto iterator = begin; iterator != end; ++iterator)
            {
                const item_type& item = *iterator;

                if(item.status() == status_type::TO_REMOVE)
                {
                    int padding_blocks_count = _padding_blocks_count<tiles>(item.start_block, blocks_count,
                                                                            create_data.bpp);

                    if(item.blocks_count == blocks_count + padding_blocks_count)
                    {
                        return _create_item(iterator.id(), padding_blocks_count, true, move(create_data));
                    }
                }
            }
        }

        if(blocks_count <= data.free_blocks_count)
        {
            auto smallest_iterator = end;
            int smallest_blocks_count = numeric_limits<int>::max();
            int smallest_padding_blocks_count = 0;

            for(auto iterator = begin; iterator != end; ++iterator)
            {
                const item_type& item = *iterator;

                if(item.status() == status_type::FREE)
                {
                    int padding_blocks_count = _padding_blocks_count<tiles>(item.start_block, blocks_count,
                                                                            create_data.bpp);
                    int requested_blocks_count = blocks_count + padding_blocks_count;

                    if(item.blocks_count > requested_blocks_count)
                    {
                        if(item.blocks_count < smallest_blocks_count)
                        {
                            smallest_iterator = iterator;
                            smallest_blocks_count = item.blocks_count;
                            smallest_padding_blocks_count = padding_blocks_count;
                        }
                    }
                    else if(item.blocks_count == requested_blocks_count)
                    {
                        return _create_item(iterator.id(), padding_blocks_count, data.delay_commit, move(create_data));
                    }
                }
            }

            if(smallest_iterator != end)
            {
                return _create_item(smallest_iterator.id(), smallest_padding_blocks_count, data.delay_commit,
                                    move(create_data));
            }
        }

        if(check_to_remove_blocks && ! data.delay_commit)
        {
            update();
            data.delay_commit = true;
            return _create_impl<tiles>(move(create_data));
        }

        return -1;
    }

    template<bool tiles>
    [[nodiscard]] int _allocate_impl(create_data&& create_data)
    {
        if(data.delay_commit)
        {
            return -1;
        }

        int blocks_count = create_data.blocks_count;

        if(blocks_count <= data.free_blocks_count)
        {
            auto end = data.items.end();
            auto smallest_iterator = end;
            int smallest_blocks_count = numeric_limits<int>::max();
            int smallest_padding_blocks_count = 0;

            for(auto iterator = data.items.begin(); iterator != end; ++iterator)
            {
                const item_type& item = *iterator;

                if(item.status() == status_type::FREE)
                {
                    int padding_blocks_count = _padding_blocks_count<tiles>(item.start_block, blocks_count,
                                                                            create_data.bpp);
                    int requested_blocks_count = blocks_count + padding_blocks_count;

                    if(item.blocks_count > requested_blocks_count)
                    {
                        if(item.blocks_count < smallest_blocks_count)
                        {
                            smallest_iterator = iterator;
                            smallest_blocks_count = item.blocks_count;
                            smallest_padding_blocks_count = padding_blocks_count;
                        }
                    }
                    else if(item.blocks_count == requested_blocks_count)
                    {
                        return _create_item(iterator.id(), padding_blocks_count, false, move(create_data));
                    }
                }
            }

            if(smallest_iterator != end)
            {
                return _create_item(smallest_iterator.id(), smallest_padding_blocks_count, false, move(create_data));
            }
        }

        return -1;
    }

    [[nodiscard]] bool _remove_adjacent_item(int adjacent_id, item_type& current_item)
    {
        const item_type& adjacent_item = data.items.item(adjacent_id);
        status_type adjacent_item_status = adjacent_item.status();
        bool remove = adjacent_item_status != status_type::USED;

        if(remove)
        {
            current_item.blocks_count += adjacent_item.blocks_count;

            if(adjacent_item_status == status_type::TO_REMOVE)
            {
                if(adjacent_item.data)
                {
                    data.items_map.erase(adjacent_item.data);
                }

                data.free_blocks_count += adjacent_item.blocks_count;
            }
        }

        return remove;
    }
}

void init()
{
    BN_BG_BLOCKS_LOG("bg_blocks_manager - INIT");

    item_type new_item;
    new_item.blocks_count = hw::bg_tiles::blocks_count();
    data.items.init();
    data.items.push_front(new_item);
    data.free_blocks_count = new_item.blocks_count;

    BN_BG_BLOCKS_LOG_STATUS();
}

int used_tiles_count()
{
    return _blocks_to_tiles(used_tile_blocks_count());
}

int available_tiles_count()
{
    return _blocks_to_tiles(available_tile_blocks_count());
}

int used_tile_blocks_count()
{
    int result = 0;

    for(const item_type& item : data.items)
    {
        if(item.status() != status_type::FREE && item.is_tiles)
        {
            result += item.blocks_count;
        }
    }

    return result;
}

int available_tile_blocks_count()
{
    return data.free_blocks_count;
}

int used_map_cells_count()
{
    return _blocks_to_half_words(used_map_blocks_count());
}

int available_map_cells_count()
{
    return _blocks_to_half_words(available_map_blocks_count());
}

int used_map_blocks_count()
{
    int result = 0;

    for(const item_type& item : data.items)
    {
        if(item.status() != status_type::FREE && ! item.is_tiles)
        {
            result += item.blocks_count;
        }
    }

    return result;
}

int available_map_blocks_count()
{
    return data.free_blocks_count;
}

#if BN_CFG_LOG_ENABLED
    void log_status()
    {
        #if BN_CFG_BG_BLOCKS_LOG_ENABLED
            BN_BG_BLOCKS_LOG_STATUS();
        #else
            BN_LOG("items: ", data.items.size());
            BN_LOG('[');

            for(const item_type& item : data.items)
            {
                if(item.status() == status_type::FREE)
                {
                    BN_LOG("    ",
                            "free",
                            " - start_block: ", item.start_block,
                            " - blocks_count: ", item.blocks_count);
                }
                else if(item.is_tiles)
                {
                    BN_LOG("    ",
                            (item.status() == status_type::USED ? "used" : "to_remove"),
                            "_tiles",
                            " - start_block: ", item.start_block,
                            " - blocks_count: ", item.blocks_count,
                            " - data: ", item.data,
                            " - usages: ", item.usages,
                            " - tiles: ", item.tiles_count());
                }
                else
                {
                    BN_LOG("    ",
                            (item.status() == status_type::USED ? "used" : "to_remove"),
                            "_map",
                            " - start_block: ", item.start_block,
                            " - blocks_count: ", item.blocks_count,
                            " - data: ", item.data,
                            " - usages: ", item.usages,
                            " - width: ", item.width,
                            " - height: ", item.height,
                            " - tiles: ", (item.tiles ? item.tiles->id() : -1),
                            " - palette: ", (item.palette ? item.palette->id() : -1));
                }
            }

            BN_LOG(']');

            BN_LOG("free_blocks_count: ", data.free_blocks_count);
            BN_LOG("to_remove_blocks_count: ", data.to_remove_blocks_count);
        #endif
    }
#endif

int find_tiles(const bg_tiles_item& tiles_item)
{
    const span<const tile>& tiles_ref = tiles_item.tiles_ref();
    auto tiles_data = reinterpret_cast<const uint16_t*>(tiles_ref.data());
    int tiles_count = tiles_ref.size();

    BN_BG_BLOCKS_LOG("bg_blocks_manager - FIND TILES: ", tiles_data, " - ", tiles_count);

    int half_words = _tiles_to_half_words(tiles_count);
    return _find_tiles_impl(tiles_data, half_words);
}

int find_regular_map(const regular_bg_map_item& map_item, const bg_tiles_ptr& tiles, const bg_palette_ptr& palette)
{
    BN_BG_BLOCKS_LOG("bg_blocks_manager - FIND REGULAR MAP: ", &map_item.cells_ref(), " - ",
                     map_item.dimensions().width(), " - ", map_item.dimensions().height(), " - ", palette.id());

    return _find_regular_map_impl(map_item, tiles, palette);
}

int create_tiles(const bg_tiles_item& tiles_item)
{
    const span<const tile>& tiles_ref = tiles_item.tiles_ref();
    auto tiles_data = reinterpret_cast<const uint16_t*>(tiles_ref.data());
    int tiles_count = tiles_ref.size();
    int half_words = _tiles_to_half_words(tiles_count);
    bpp_mode bpp = tiles_item.bpp();

    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE TILES: ", tiles_data, " - ", tiles_count, " - ",
                     _ceil_half_words_to_blocks(half_words), " - ", int(bpp));

    int result = _find_tiles_impl(tiles_data, half_words);

    if(result != -1)
    {
        return result;
    }

    result = _create_impl<true>(create_data::from_tiles(tiles_data, half_words, bpp));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");

        #if BN_CFG_LOG_ENABLED
            log_status();

            BN_ERROR("BG tiles create failed:",
                      "\n\tTiles data: ", tiles_data,
                      "\n\tTiles count: ", tiles_count,
                      "\n\nBG blocks manager status has been logged.");
        #else
            BN_ERROR("BG tiles create failed:",
                      "\n\tTiles data: ", tiles_data,
                      "\n\tTiles count: ", tiles_count);
        #endif
    }

    return result;
}

int create_regular_map(const regular_bg_map_item& map_item, bg_tiles_ptr&& tiles, bg_palette_ptr&& palette)
{
    const uint16_t* data_ptr = &map_item.cells_ref();
    const size& dimensions = map_item.dimensions();
    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE REGULAR MAP: ", data_ptr, " - ", dimensions.width(), " - ",
                     dimensions.height(), " - ", tiles.id(), " - ", palette.id());

    int result = _find_regular_map_impl(map_item, tiles, palette);

    if(result != -1)
    {
        return result;
    }

    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), palette.bpp()),
              "Invalid tiles count: ", tiles.tiles_count(), " - ", int(palette.bpp()));

    result = _create_impl<false>(create_data::from_map(data_ptr, dimensions, move(tiles), move(palette)));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");

        #if BN_CFG_LOG_ENABLED
            log_status();

            BN_ERROR("Regular BG map create failed:",
                      "\n\tMap data: ", data_ptr,
                      "\n\tMap width: ", dimensions.width(),
                      "\n\tMap height: ", dimensions.height(),
                      "\n\nBG blocks manager status has been logged.");
        #else
            BN_ERROR("Regular BG map create failed:",
                     "\n\tMap data: ", data_ptr,
                     "\n\tMap width: ", dimensions.width(),
                     "\n\tMap height: ", dimensions.height());
        #endif
    }

    return result;
}

int create_new_tiles(const bg_tiles_item& tiles_item)
{
    const span<const tile>& tiles_ref = tiles_item.tiles_ref();
    auto data_ptr = reinterpret_cast<const uint16_t*>(tiles_ref.data());
    int tiles_count = tiles_ref.size();
    int half_words = _tiles_to_half_words(tiles_count);
    bpp_mode bpp = tiles_item.bpp();

    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE NEW TILES: ", data_ptr, " - ", tiles_count, " - ",
                     _ceil_half_words_to_blocks(half_words), " - ", int(bpp));

    BN_ASSERT(data.items_map.find(data_ptr) == data.items_map.end(),
              "Multiple copies of the same data not supported");

    int result = _create_impl<true>(create_data::from_tiles(data_ptr, half_words, bpp));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");

        #if BN_CFG_LOG_ENABLED
            log_status();

            BN_ERROR("BG tiles create new failed:",
                      "\n\tTiles data: ", data_ptr,
                      "\n\tTiles count: ", tiles_count,
                      "\n\nBG blocks manager status has been logged.");
        #else
            BN_ERROR("BG tiles create new failed:",
                      "\n\tTiles data: ", data_ptr,
                      "\n\tTiles count: ", tiles_count);
        #endif
    }

    return result;
}

int create_new_regular_map(const regular_bg_map_item& map_item, bg_tiles_ptr&& tiles, bg_palette_ptr&& palette)
{
    const uint16_t* data_ptr = &map_item.cells_ref();
    const size& dimensions = map_item.dimensions();
    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE NEW REGULAR MAP: ", data_ptr, " - ", dimensions.width(), " - ",
                     dimensions.height(), " - ", tiles.id(), " - ", palette.id());

    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), palette.bpp()),
              "Invalid tiles count: ", tiles.tiles_count(), " - ", int(palette.bpp()));
    BN_ASSERT(data.items_map.find(data_ptr) == data.items_map.end(),
              "Multiple copies of the same data not supported");

    int result = _create_impl<false>(create_data::from_map(data_ptr, dimensions, move(tiles), move(palette)));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");

        #if BN_CFG_LOG_ENABLED
            log_status();

            BN_ERROR("Regular BG map create new failed:",
                      "\n\tMap data: ", data_ptr,
                      "\n\tMap width: ", dimensions.width(),
                      "\n\tMap height: ", dimensions.height(),
                      "\n\nBG blocks manager status has been logged.");
        #else
            BN_ERROR("Regular BG map create new failed:",
                      "\n\tMap data: ", data_ptr,
                      "\n\tMap width: ", dimensions.width(),
                      "\n\tMap height: ", dimensions.height());
        #endif
    }

    return result;
}

int allocate_tiles(int tiles_count, bpp_mode bpp)
{
    int half_words = _tiles_to_half_words(tiles_count);

    BN_BG_BLOCKS_LOG("bg_blocks_manager - ALLOCATE TILES: ", tiles_count, " - ",
                     _ceil_half_words_to_blocks(half_words), " - ", int(bpp));

    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles_count, bpp),
              "Invalid tiles count: ", tiles_count, " - ", int(bpp));

    int result = _allocate_impl<true>(create_data::from_tiles(nullptr, half_words, bpp));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("ALLOCATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT ALLOCATED");

        #if BN_CFG_LOG_ENABLED
            log_status();

            BN_ERROR("BG tiles allocate failed. Tiles count: ", tiles_count,
                      "\n\nBG blocks manager status has been logged.");
        #else
            BN_ERROR("BG tiles allocate failed. Tiles count: ", tiles_count);
        #endif
    }

    return result;
}

int allocate_regular_map(const size& map_dimensions, bg_tiles_ptr&& tiles, bg_palette_ptr&& palette)
{
    BN_BG_BLOCKS_LOG("bg_blocks_manager - ALLOCATE REGULAR MAP: ", map_dimensions.width(), " - ",
                     map_dimensions.height(), " - ", tiles.id(), " - ", palette.id());

    BN_ASSERT(map_dimensions.width() == 32 || map_dimensions.width() == 64,
              "Invalid map width: ", map_dimensions.width());
    BN_ASSERT(map_dimensions.height() == 32 || map_dimensions.height() == 64,
              "Invalid map height: ", map_dimensions.height());
    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), palette.bpp()),
              "Invalid tiles count: ", tiles.tiles_count(), " - ", int(palette.bpp()));

    int result = _allocate_impl<false>(create_data::from_map(nullptr, map_dimensions, move(tiles), move(palette)));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("ALLOCATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT ALLOCATED");

        #if BN_CFG_LOG_ENABLED
            log_status();

            BN_ERROR("Regular BG map allocate failed:",
                      "\n\tMap width: ", map_dimensions.width(),
                      "\n\tMap height: ", map_dimensions.height(),
                      "\n\nBG blocks manager status has been logged.");
        #else
            BN_ERROR("Regular BG map allocate failed:",
                      "\n\tMap width: ", map_dimensions.width(),
                      "\n\tMap height: ", map_dimensions.height());
        #endif
    }

    return result;
}

int create_tiles_optional(const bg_tiles_item& tiles_item)
{
    const span<const tile>& tiles_ref = tiles_item.tiles_ref();
    auto tiles_data = reinterpret_cast<const uint16_t*>(tiles_ref.data());
    int tiles_count = tiles_ref.size();
    int half_words = _tiles_to_half_words(tiles_count);
    bpp_mode bpp = tiles_item.bpp();

    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE TILES OPTIONAL: ", tiles_data, " - ", tiles_count, " - ",
                     _ceil_half_words_to_blocks(half_words), " - ", int(bpp));

    int result = _find_tiles_impl(tiles_data, half_words);

    if(result != -1)
    {
        return result;
    }

    result = _create_impl<true>(create_data::from_tiles(tiles_data, half_words, bpp));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");
    }

    return result;
}

int create_regular_map_optional(const regular_bg_map_item& map_item, bg_tiles_ptr&& tiles, bg_palette_ptr&& palette)
{
    const uint16_t* data_ptr = &map_item.cells_ref();
    const size& dimensions = map_item.dimensions();
    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE REGULAR MAP OPTIONAL: ", data_ptr, " - ", dimensions.width(), " - ",
                     dimensions.height(), " - ", tiles.id(), " - ", palette.id());

    int result = _find_regular_map_impl(map_item, tiles, palette);

    if(result != -1)
    {
        return result;
    }

    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), palette.bpp()),
              "Invalid tiles count: ", tiles.tiles_count(), " - ", int(palette.bpp()));

    result = _create_impl<false>(create_data::from_map(data_ptr, dimensions, move(tiles), move(palette)));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");
    }

    return result;
}

int create_new_tiles_optional(const bg_tiles_item& tiles_item)
{
    const span<const tile>& tiles_ref = tiles_item.tiles_ref();
    auto data_ptr = reinterpret_cast<const uint16_t*>(tiles_ref.data());
    int tiles_count = tiles_ref.size();
    int half_words = _tiles_to_half_words(tiles_count);
    bpp_mode bpp = tiles_item.bpp();

    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE NEW TILES OPTIONAL: ", data_ptr, " - ", tiles_count, " - ",
                     _ceil_half_words_to_blocks(half_words), " - ", int(bpp));

    BN_ASSERT(data.items_map.find(data_ptr) == data.items_map.end(),
              "Multiple copies of the same data not supported");

    int result = _create_impl<true>(create_data::from_tiles(data_ptr, half_words, bpp));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");
    }

    return result;
}

int create_new_regular_map_optional(const regular_bg_map_item& map_item, bg_tiles_ptr&& tiles,
                                    bg_palette_ptr&& palette)
{
    const uint16_t* data_ptr = &map_item.cells_ref();
    const size& dimensions = map_item.dimensions();
    BN_BG_BLOCKS_LOG("bg_blocks_manager - CREATE NEW REGULAR MAP OPTIONAL: ", data_ptr, " - ",
                     dimensions.width(), " - ", dimensions.height(), " - ", tiles.id(), " - ", palette.id());

    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), palette.bpp()),
              "Invalid tiles count: ", tiles.tiles_count(), " - ", int(palette.bpp()));
    BN_ASSERT(data.items_map.find(data_ptr) == data.items_map.end(),
              "Multiple copies of the same data not supported");

    int result = _create_impl<false>(create_data::from_map(data_ptr, dimensions, move(tiles), move(palette)));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("CREATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT CREATED");
    }

    return result;
}

int allocate_tiles_optional(int tiles_count, bpp_mode bpp)
{
    int half_words = _tiles_to_half_words(tiles_count);

    BN_BG_BLOCKS_LOG("bg_blocks_manager - ALLOCATE TILES OPTIONAL: ", tiles_count, " - ",
                     _ceil_half_words_to_blocks(half_words), " - ", int(bpp));

    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles_count, bpp),
              "Invalid tiles count: ", tiles_count, " - ", int(bpp));

    int result = _allocate_impl<true>(create_data::from_tiles(nullptr, half_words, bpp));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("ALLOCATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT ALLOCATED");
    }

    return result;
}

int allocate_regular_map_optional(const size& map_dimensions, bg_tiles_ptr&& tiles, bg_palette_ptr&& palette)
{
    BN_BG_BLOCKS_LOG("bg_blocks_manager - ALLOCATE REGULAR MAP OPTIONAL: ", map_dimensions.width(), " - ",
                     map_dimensions.height(), " - ", tiles.id(), " - ", palette.id());

    BN_ASSERT(map_dimensions.width() == 32 || map_dimensions.width() == 64,
              "Invalid map width: ", map_dimensions.width());
    BN_ASSERT(map_dimensions.height() == 32 || map_dimensions.height() == 64,
              "Invalid map height: ", map_dimensions.height());
    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), palette.bpp()),
              "Invalid tiles count: ", tiles.tiles_count(), " - ", int(palette.bpp()));

    int result = _allocate_impl<false>(create_data::from_map(nullptr, map_dimensions, move(tiles), move(palette)));

    if(result != -1)
    {
        BN_BG_BLOCKS_LOG("ALLOCATED. start_block: ", data.items.item(result).start_block);
        BN_BG_BLOCKS_LOG_STATUS();
    }
    else
    {
        BN_BG_BLOCKS_LOG("NOT ALLOCATED");
    }

    return result;
}

void increase_usages(int id)
{
    BN_BG_BLOCKS_LOG("bg_blocks_manager - INCREASE_USAGES: ", id, " - ", data.items.item(id).start_block);

    item_type& item = data.items.item(id);
    ++item.usages;

    BN_BG_BLOCKS_LOG_STATUS();
}

void decrease_usages(int id)
{
    BN_BG_BLOCKS_LOG("bg_blocks_manager - DECREASE_USAGES: ", id, " - ", data.items.item(id).start_block);

    item_type& item = data.items.item(id);
    --item.usages;

    if(! item.usages)
    {
        item.set_status(status_type::TO_REMOVE);
        data.to_remove_blocks_count += item.blocks_count;

        item.tiles.reset();
        item.palette.reset();
    }

    BN_BG_BLOCKS_LOG_STATUS();
}

int hw_id(int id)
{
    const item_type& item = data.items.item(id);
    return item.start_block;
}

int hw_tiles_cbb(int id)
{
    return hw_id(id) / hw::bg_blocks::tiles_alignment_blocks_count();
}

int tiles_count(int id)
{
    const item_type& item = data.items.item(id);
    return item.tiles_count();
}

size map_dimensions(int id)
{
    const item_type& item = data.items.item(id);
    return size(item.width, item.height);
}

int tiles_offset(int id)
{
    const item_type& item = data.items.item(id);
    return item.tiles_offset();
}

int palette_offset(int id)
{
    const item_type& item = data.items.item(id);
    return item.palette_offset();
}

[[nodiscard]] optional<span<const tile>> tiles_ref(int id)
{
    const item_type& item = data.items.item(id);
    optional<span<const tile>> result;

    if(const uint16_t* data_ptr = item.data)
    {
        auto tiles = reinterpret_cast<const tile*>(data_ptr);
        result.emplace(tiles, item.tiles_count());
    }

    return result;
}

optional<span<const regular_bg_map_cell>> regular_map_cells_ref(int id)
{
    const item_type& item = data.items.item(id);
    optional<span<const regular_bg_map_cell>> result;

    if(item.data)
    {
        result.emplace(item.data, item.width * item.height);
    }

    return result;
}

void set_tiles_ref(int id, const bg_tiles_item& tiles_item)
{
    const span<const tile>& tiles_ref = tiles_item.tiles_ref();
    auto data_ptr = reinterpret_cast<const uint16_t*>(tiles_ref.data());

    BN_BG_BLOCKS_LOG("bg_blocks_manager - SET TILES REF: ", id, " - ", data.items.item(id).start_block, " - ",
                     data_ptr, " - ", tiles_ref.size());

    item_type& item = data.items.item(id);
    BN_ASSERT(item.data, "Item has no data");
    BN_ASSERT(_tiles_to_half_words(tiles_ref.size()) == item.half_words(),
              "Tiles count does not match item tiles count: ",
              _tiles_to_half_words(tiles_ref.size()), " - ", item.half_words());

    if(item.data != data_ptr)
    {
        BN_ASSERT(data.items_map.find(data_ptr) == data.items_map.end(),
                  "Multiple copies of the same data not supported");

        data.items_map.erase(item.data);
        _check_commit_item(id, data_ptr, true);

        BN_BG_BLOCKS_LOG_STATUS();
    }
}

void set_regular_map_cells_ref(int id, const regular_bg_map_item& map_item)
{
    const uint16_t* data_ptr = &map_item.cells_ref();

    BN_BG_BLOCKS_LOG("bg_blocks_manager - SET REGULAR MAP CELLS REF: ", id, " - ", data.items.item(id).start_block,
                     " - ", data_ptr, " - ", map_item.dimensions().width(), " - ", map_item.dimensions().height());

    item_type& item = data.items.item(id);
    BN_ASSERT(item.data, "Item has no data");

    if(item.data != data_ptr)
    {
        BN_ASSERT(data.items_map.find(data_ptr) == data.items_map.end(),
                  "Multiple copies of the same data not supported");

        data.items_map.erase(item.data);
        _check_commit_item(id, data_ptr, true);

        BN_BG_BLOCKS_LOG_STATUS();
    }
}

void reload(int id)
{
    BN_BG_BLOCKS_LOG("bg_blocks_manager - RELOAD: ", id, " - ", data.items.item(id).start_block);

    item_type& item = data.items.item(id);
    BN_ASSERT(item.data, "Item has no data");

    item.commit = true;
    data.check_commit = true;

    BN_BG_BLOCKS_LOG_STATUS();
}

const bg_tiles_ptr& map_tiles(int id)
{
    const item_type& item = data.items.item(id);
    return *item.tiles;
}

void set_map_tiles(int id, bg_tiles_ptr&& tiles)
{
    item_type& item = data.items.item(id);

    if(tiles != item.tiles)
    {
        BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), item.palette->bpp()),
                  "Invalid tiles count: ", tiles.tiles_count(), " - ", int(item.palette->bpp()));

        int old_tiles_cbb;
        int old_tiles_offset;

        if(item.tiles)
        {
            old_tiles_cbb = item.tiles->cbb();
            old_tiles_offset = item.tiles_offset();
        }
        else
        {
            old_tiles_cbb = -1;
            old_tiles_offset = -1;
        }

        int new_tiles_cbb = tiles.cbb();

        if(new_tiles_cbb != old_tiles_cbb)
        {
            bgs_manager::update_map_tiles_cbb(item.start_block, new_tiles_cbb);
        }

        item.tiles = move(tiles);

        if(item.tiles_offset() != old_tiles_offset)
        {
            item.commit = true;
            data.check_commit = true;
        }
    }
}

void remove_map_tiles(int id)
{
    item_type& item = data.items.item(id);
    item.tiles.reset();
}

const bg_palette_ptr& map_palette(int id)
{
    const item_type& item = data.items.item(id);
    return *item.palette;
}

void set_map_palette(int id, bg_palette_ptr&& palette)
{
    item_type& item = data.items.item(id);

    if(palette != item.palette)
    {
        bpp_mode new_palette_bpp = palette.bpp();
        BN_ASSERT(bg_tiles_item::valid_tiles_count(item.tiles->tiles_count(), new_palette_bpp),
                  "Invalid palette BPP: ", item.tiles->tiles_count(), " - ", int(new_palette_bpp));

        int old_palette_bpp;
        int old_tiles_offset;
        int old_palette_offset;

        if(item.palette)
        {
            old_palette_bpp = int(item.palette->bpp());
            old_tiles_offset = item.tiles_offset();
            old_palette_offset = item.palette_offset();
        }
        else
        {
            old_palette_bpp = -1;
            old_tiles_offset = -1;
            old_palette_offset = -1;
        }

        if(int(new_palette_bpp) != old_palette_bpp)
        {
            bgs_manager::update_map_palette_bpp(item.start_block, new_palette_bpp);
        }

        item.palette = move(palette);

        if(item.tiles_offset() != old_tiles_offset || item.palette_offset() != old_palette_offset)
        {
            item.commit = true;
            data.check_commit = true;
        }
    }
}

void remove_map_palette(int id)
{
    item_type& item = data.items.item(id);
    item.palette.reset();
}

void set_map_tiles_and_palette(int id, bg_tiles_ptr&& tiles, bg_palette_ptr&& palette)
{
    item_type& item = data.items.item(id);
    bpp_mode new_palette_bpp = palette.bpp();
    BN_ASSERT(bg_tiles_item::valid_tiles_count(tiles.tiles_count(), new_palette_bpp),
              "Invalid tiles count or palette BPP: ", tiles.tiles_count(), " - ", int(new_palette_bpp));

    int old_tiles_offset;
    int old_palette_offset;

    if(item.tiles && item.palette)
    {
        old_tiles_offset = item.tiles_offset();
        old_palette_offset = item.palette_offset();
    }
    else
    {
        old_tiles_offset = -1;
        old_palette_offset = -1;
    }

    if(tiles != item.tiles)
    {
        int old_tiles_cbb = item.tiles ? item.tiles->cbb() : -1;
        int new_tiles_cbb = tiles.cbb();

        if(new_tiles_cbb != old_tiles_cbb)
        {
            bgs_manager::update_map_tiles_cbb(item.start_block, new_tiles_cbb);
        }

        item.tiles = move(tiles);
    }

    if(palette != item.palette)
    {
        int old_palette_bpp = item.palette ? int(item.palette->bpp()) : -1;

        if(int(new_palette_bpp) != old_palette_bpp)
        {
            bgs_manager::update_map_palette_bpp(item.start_block, new_palette_bpp);
        }

        item.palette = move(palette);
    }

    if(item.tiles_offset() != old_tiles_offset || item.palette_offset() != old_palette_offset)
    {
        item.commit = true;
        data.check_commit = true;
    }
}

optional<span<tile>> tiles_vram(int id)
{
    const item_type& item = data.items.item(id);
    optional<span<tile>> result;

    if(! item.data)
    {
        auto vram_ptr = reinterpret_cast<tile*>(hw::bg_blocks::vram(item.start_block));
        result.emplace(vram_ptr, item.tiles_count());
    }

    return result;
}

optional<span<regular_bg_map_cell>> regular_map_vram(int id)
{
    const item_type& item = data.items.item(id);
    optional<span<regular_bg_map_cell>> result;

    if(! item.data)
    {
        regular_bg_map_cell* vram_ptr = hw::bg_blocks::vram(item.start_block);
        result.emplace(vram_ptr, item.half_words());
    }

    return result;
}

bool must_commit(int id)
{
    const item_type& item = data.items.item(id);
    return item.commit;
}

void update_regular_map_col(int id, int x, int y)
{
    const item_type& item = data.items.item(id);
    const regular_bg_map_cell* source_data = item.data;

    if(! source_data)
    {
        return;
    }

    int map_width = item.width;
    source_data += ((y * map_width) + x);

    int y_separator = y & 31;
    regular_bg_map_cell* dest_data = hw::bg_blocks::vram(item.start_block) + ((y_separator * 32) + (x & 31));
    int tiles_offset = item.tiles_offset();
    int palette_offset = item.palette_offset();

    if(tiles_offset)
    {
        if(palette_offset)
        {
            for(int iy = y_separator; iy < 32; ++iy)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_offset(*source_data, tiles_offset, palette_offset, *dest_data);
                dest_data += 32;
                source_data += map_width;
            }

            dest_data -= 1024;

            for(int iy = 0; iy < y_separator; ++iy)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_offset(*source_data, tiles_offset, palette_offset, *dest_data);
                dest_data += 32;
                source_data += map_width;
            }
        }
        else
        {
            for(int iy = y_separator; iy < 32; ++iy)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_tiles_offset(*source_data, tiles_offset, *dest_data);
                dest_data += 32;
                source_data += map_width;
            }

            dest_data -= 1024;

            for(int iy = 0; iy < y_separator; ++iy)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_tiles_offset(*source_data, tiles_offset, *dest_data);
                dest_data += 32;
                source_data += map_width;
            }
        }
    }
    else
    {
        if(palette_offset)
        {
            for(int iy = y_separator; iy < 32; ++iy)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_palette_offset(*source_data, palette_offset, *dest_data);
                dest_data += 32;
                source_data += map_width;
            }

            dest_data -= 1024;

            for(int iy = 0; iy < y_separator; ++iy)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_palette_offset(*source_data, palette_offset, *dest_data);
                dest_data += 32;
                source_data += map_width;
            }
        }
        else
        {
            for(int iy = y_separator; iy < 32; ++iy)
            {
                *dest_data = *source_data;
                dest_data += 32;
                source_data += map_width;
            }

            dest_data -= 1024;

            for(int iy = 0; iy < y_separator; ++iy)
            {
                *dest_data = *source_data;
                dest_data += 32;
                source_data += map_width;
            }
        }
    }
}

void update_regular_map_row(int id, int x, int y)
{
    const item_type& item = data.items.item(id);
    const regular_bg_map_cell* source_data = item.data;

    if(! source_data)
    {
        return;
    }

    source_data += ((y * item.width) + x);

    int x_separator = x & 31;
    regular_bg_map_cell* dest_data = hw::bg_blocks::vram(item.start_block) + (((y & 31) * 32) + x_separator);
    int tiles_offset = item.tiles_offset();
    int palette_offset = item.palette_offset();

    if(tiles_offset)
    {
        if(palette_offset)
        {
            for(int ix = x_separator; ix < 32; ++ix)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_offset(*source_data, tiles_offset, palette_offset, *dest_data);
                ++source_data;
                ++dest_data;
            }

            dest_data -= 32;

            for(int ix = 0; ix < x_separator; ++ix)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_offset(*source_data, tiles_offset, palette_offset, *dest_data);
                ++source_data;
                ++dest_data;
            }
        }
        else
        {
            for(int ix = x_separator; ix < 32; ++ix)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_tiles_offset(*source_data, tiles_offset, *dest_data);
                ++source_data;
                ++dest_data;
            }

            dest_data -= 32;

            for(int ix = 0; ix < x_separator; ++ix)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_tiles_offset(*source_data, tiles_offset, *dest_data);
                ++source_data;
                ++dest_data;
            }
        }
    }
    else
    {
        if(palette_offset)
        {
            for(int ix = x_separator; ix < 32; ++ix)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_palette_offset(*source_data, palette_offset, *dest_data);
                ++source_data;
                ++dest_data;
            }

            dest_data -= 32;

            for(int ix = 0; ix < x_separator; ++ix)
            {
                hw::bg_blocks::copy_regular_bg_map_cell_palette_offset(*source_data, palette_offset, *dest_data);
                ++source_data;
                ++dest_data;
            }
        }
        else
        {
            int elements = 32 - x_separator;
            memory::copy(*source_data, elements, *dest_data);
            source_data += elements;
            dest_data -= x_separator;
            memory::copy(*source_data, x_separator, *dest_data);
        }
    }
}

void set_regular_map_position(int id, int x, int y)
{
    const item_type& item = data.items.item(id);
    const regular_bg_map_cell* item_data = item.data;

    if(! item_data)
    {
        return;
    }

    regular_bg_map_cell* vram_data = hw::bg_blocks::vram(item.start_block);
    int map_width = item.width;
    int x_separator = x & 31;
    int tiles_offset = item.tiles_offset();
    int palette_offset = item.palette_offset();

    if(tiles_offset)
    {
        if(palette_offset)
        {
            for(int row = y, row_limit = y + 22; row < row_limit; ++row)
            {
                const regular_bg_map_cell* source_data = item_data + ((row * map_width) + x);
                regular_bg_map_cell* dest_data = vram_data + (((row & 31) * 32) + x_separator);

                for(int ix = x_separator; ix < 32; ++ix)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_offset(*source_data, tiles_offset, palette_offset,
                                                                   *dest_data);
                    ++source_data;
                    ++dest_data;
                }

                dest_data -= 32;

                for(int ix = 0; ix < x_separator; ++ix)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_offset(*source_data, tiles_offset, palette_offset,
                                                                   *dest_data);
                    ++source_data;
                    ++dest_data;
                }
            }
        }
        else
        {
            for(int row = y, row_limit = y + 22; row < row_limit; ++row)
            {
                const regular_bg_map_cell* source_data = item_data + ((row * map_width) + x);
                regular_bg_map_cell* dest_data = vram_data + (((row & 31) * 32) + x_separator);

                for(int ix = x_separator; ix < 32; ++ix)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_tiles_offset(*source_data, tiles_offset, *dest_data);
                    ++source_data;
                    ++dest_data;
                }

                dest_data -= 32;

                for(int ix = 0; ix < x_separator; ++ix)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_tiles_offset(*source_data, tiles_offset, *dest_data);
                    ++source_data;
                    ++dest_data;
                }
            }
        }
    }
    else
    {
        if(palette_offset)
        {
            for(int row = y, row_limit = y + 22; row < row_limit; ++row)
            {
                const regular_bg_map_cell* source_data = item_data + ((row * map_width) + x);
                regular_bg_map_cell* dest_data = vram_data + (((row & 31) * 32) + x_separator);

                for(int ix = x_separator; ix < 32; ++ix)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_palette_offset(*source_data, palette_offset, *dest_data);
                    ++source_data;
                    ++dest_data;
                }

                dest_data -= 32;

                for(int ix = 0; ix < x_separator; ++ix)
                {
                    hw::bg_blocks::copy_regular_bg_map_cell_palette_offset(*source_data, palette_offset, *dest_data);
                    ++source_data;
                    ++dest_data;
                }
            }
        }
        else
        {
            for(int row = y, row_limit = y + 22; row < row_limit; ++row)
            {
                const regular_bg_map_cell* source_data = item_data + ((row * map_width) + x);
                regular_bg_map_cell* dest_data = vram_data + (((row & 31) * 32) + x_separator);
                int elements = 32 - x_separator;
                memory::copy(*source_data, elements, *dest_data);
                source_data += elements;
                dest_data -= x_separator;
                memory::copy(*source_data, x_separator, *dest_data);
            }
        }
    }
}

void update()
{
    if(data.to_remove_blocks_count)
    {
        BN_BG_BLOCKS_LOG("bg_blocks_manager - UPDATE");

        auto end = data.items.end();
        auto before_previous_iterator = end;
        auto previous_iterator = data.items.before_begin();
        auto iterator = previous_iterator;
        ++iterator;
        data.to_remove_blocks_count = 0;

        while(iterator != end)
        {
            item_type& item = *iterator;

            if(item.status() == status_type::TO_REMOVE)
            {
                if(item.data)
                {
                    data.items_map.erase(item.data);
                }

                item.data = nullptr;
                item.width = 0;
                item.height = 0;
                item.set_status(status_type::FREE);
                item.commit = false;
                data.free_blocks_count += item.blocks_count;

                auto next_iterator = iterator;
                ++next_iterator;

                while(next_iterator != end)
                {
                    if(_remove_adjacent_item(next_iterator.id(), item))
                    {
                        next_iterator = data.items.erase_after(iterator.id());
                    }
                    else
                    {
                        break;
                    }
                }

                if(before_previous_iterator != end)
                {
                    if(_remove_adjacent_item(previous_iterator.id(), item))
                    {
                        item.start_block = previous_iterator->start_block;
                        data.items.erase_after(before_previous_iterator.id());
                        previous_iterator = before_previous_iterator;
                    }
                }
            }

            before_previous_iterator = previous_iterator;
            previous_iterator = iterator;
            ++iterator;
        }

        BN_BG_BLOCKS_LOG_STATUS();
    }
}

void commit()
{
    bool do_commit = data.check_commit;

    if(do_commit)
    {
        BN_BG_BLOCKS_LOG("bg_blocks_manager - COMMIT");

        data.check_commit = false;

        for(item_type& item : data.items)
        {
            if(item.commit)
            {
                item.commit = false;

                if(item.status() == status_type::USED)
                {
                    _commit_item(item);
                }
            }
        }
    }

    data.delay_commit = false;

    if(do_commit)
    {
        BN_BG_BLOCKS_LOG_STATUS();
    }
}

}
